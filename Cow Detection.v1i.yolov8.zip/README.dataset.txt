# Cow Detection > 2026-09-12 3:35pm
https://universe.roboflow.com/helmut-ulrich/cow-detection-wgeny

Provided by a Roboflow user
License: CC BY 4.0

